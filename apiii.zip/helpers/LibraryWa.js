var WA = {

  pathwa: function ()
  {
      return SESSION_FILE_PATH='./whatsapp-session.json';
  },
}
module.exports = WA;
